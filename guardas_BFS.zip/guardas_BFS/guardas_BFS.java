import java.lang.*;
import java.util.*;

class BSTree<T extends Comparable<? super T>> {
   public BSTNode<T> root;
   BSTree() {
      root = null;
   }
   public BSTNode<T> getRoot() {return root;}
   public void setRoot(BSTNode<T> r) {root = r;}
   public boolean isEmpty() {
      return root == null;
   }
   public void clear() {
      root = null;
   }
   public int numberNodes() {
      return numberNodes(root);
   }
   private int numberNodes(BSTNode<T> n) {
      if (n == null) return 0;
      return 1 + numberNodes(n.getLeft()) + numberNodes(n.getRight());
   }
   public boolean contains(T value) {
      return contains(root, value);
   }
   private boolean contains(BSTNode<T> n, T value) {
    // int lados=0;
      if (n==null) return false;
      if (value.compareTo(n.getValue()) < 0)
         return contains(n.getLeft(), value);
      if (value.compareTo(n.getValue()) >= 0)
         return contains(n.getRight(), value);
      return true;
   }
   public boolean insert(T value, int x, int y, int retangulo) {
       root = insert(root, value, x, y, retangulo);
       return true;
    }
    int lados=0;
    int flag_lados=0;
    private BSTNode<T> insert(BSTNode<T> n, T value, int x, int y,int retangulo) {
       int vec[] = { retangulo, 0, 0, };
       if (n==null)
          return new BSTNode<T>(value, null, null,x,y,vec,0);
       else if (value.compareTo(n.getValue()) < 0)
          n.setLeft(insert(n.getLeft(), value,x,y,retangulo));
       else if (value.compareTo(n.getValue()) >= 0)
          n.setRight(insert(n.getRight(), value,x,y,retangulo));
       return n;
    }
   public boolean remove(T value) {
      if (!contains(value)) return false;
      root = remove(root, value);
      return true;
   }
   private BSTNode<T> remove(BSTNode<T> n, T value) {
      if (value.compareTo(n.getValue()) < 0)
         n.setLeft(remove(n.getLeft(), value));
      else if (value.compareTo(n.getValue()) > 0)
         n.setRight(remove(n.getRight(), value));
      else if (n.getLeft() == null) // Nao tem filho esquerdo
         n = n.getRight();
      else if (n.getRight() == null) // Nao tem filho direito
         n = n.getLeft();
      else { // Dois fihos: ir buscar maximo do lado esquerdo
         BSTNode<T> max = n.getLeft();
         while (max.getRight() != null) max = max.getRight();
         n.setValue(max.getValue()); // Substituir valor removido
         // Apagar valor que foi para lugar do removido
         n.setLeft(remove(n.getLeft(), max.getValue()));
      }
      return n;
   }
   public int depth() {
      return depth(root);
   }

   private int depth(BSTNode<T> n) {
      if (n == null) return -1;
      return 1 + Math.max(depth(n.getLeft()), depth(n.getRight()));
   }
    public T minValue()
    {
	return minValue(root);
    }
    private T minValue(BSTNode<T> n)
    {
	if(n.getLeft()!=null)
	    {
		return minValue(n.getLeft());
	    }
	return n.getValue();
    }
    public T maxValue()
    {
	return maxValue(root);
    }
    private T maxValue(BSTNode<T> n )
    {
	if(n.getRight()!=null)
	    {
		return maxValue(n.getRight());
	    }
	return n.getValue();
    }
}


public class guardas_BFS
{
  public static int numero_retangulos;
  public static int vertices_existentes=0;
  public static void inserir(int x, int y, int retangulo, BSTree<Integer> arvore)
  {
    int flag=0;
    MyQueue<BSTNode<Integer>> q = new LinkedListQueue<BSTNode<Integer>>();
    q.enqueue(arvore.root);
    while (!q.isEmpty()) {
       BSTNode<Integer> cur = q.dequeue();
       if (cur != null) {
         if(cur.getx()==x && cur.gety()==y)
         {
           flag=1;
           cur.insert_cobertura(retangulo);
           cur.setValue(cur.contagem_value());
         }
          q.enqueue(cur.getLeft());
          q.enqueue(cur.getRight());
       }
    }
    if(flag==0)
    {
    arvore.insert(1,x,y,retangulo);
   }

  }

  public static int contar_false(boolean[] map,int nretangulos)
  {
    int contagem=0;
    for(int i=0;i<nretangulos;i++)
    {
      if(map[i]==false)
      {
        contagem++;
      }
    }
    return contagem;
  }

  public static boolean areAllTrue(boolean[] array,int nretangulos)    // Saber se o array map está totalmente "TRUE"
  {
    for(int i=0;i<nretangulos;i++)
    {
      if(array[i]==false)
      {
        return false;
      }
    }
    return true;
  }

  public static void preencher(BSTNode<Integer> n,boolean[] map)
  {
    for(int i=0;i<=2;i++)
    {
      if(n.vec[i]==0)
      {
        map[n.vec[i]]=true;
      }
      else{
        map[n.vec[i]-1]=true;
      }
    }
  }

  public static int contar(int[] array,int nretangulos)
  {
    int contagem=0;
    for(int i=0;i<vertices_existentes*2;i++)
    {
      if(array[i]>=0 && array[i+1]>=0)
      {
        contagem++;
      }
      i++;
    }
    return contagem;
  }

  public static void remover(int x , int y, BSTree<Integer> arvore)
  {
    MyQueue<BSTNode<Integer>> q = new LinkedListQueue<BSTNode<Integer>>();
    q.enqueue(arvore.root);
    while (!q.isEmpty()) {
       BSTNode<Integer> cur = q.dequeue();
       if (cur != null) {
         if(cur.getx()==x && cur.gety()==y)
         {
           cur.invisivel=1;
           break;
         }
          q.enqueue(cur.getLeft());
          q.enqueue(cur.getRight());
       }
    }
  }

  public static void colocar(int x , int y, BSTree<Integer> arvore)
  {
    MyQueue<BSTNode<Integer>> q = new LinkedListQueue<BSTNode<Integer>>();
    q.enqueue(arvore.root);
    while (!q.isEmpty()) {
       BSTNode<Integer> cur = q.dequeue();
       if (cur != null) {
         if(cur.getx()==x && cur.gety()==y)
         {
           cur.invisivel=0;
           break;
         }
          q.enqueue(cur.getLeft());
          q.enqueue(cur.getRight());
       }
    }
  }

    public static void clear_map(boolean[] map, int nretangulos)
    {
      for(int i=0;i<nretangulos;i++)
      {
        map[i]=false;
      }
    }

    public static int pertence(int x, int y, int[] removidos)
    {
      for(int i=0;i<vertices_existentes*2;i++)
      {
        if(removidos[i]==x && removidos[i+1]==y && removidos[i]>=0 && removidos[i+1]>=0)
        {
          return 1;
        }
        i++;
      }
      return 0;
    }

    public static void array_fill(int[] array,int size)
    {
      for(int i=0;i<size;i++)
      {
        array[i]=-1;
      }
    }

    public static void printar_removidos(int[] removidos,int size)
    {
      for(int i=0;i<size;i++)
      {
        System.out.println("Removidos x:"+removidos[i]+" y:"+removidos[i+1]);
        i++;
      }
    }
    public static void printar_solucao(int[] removidos,int size)
    {
      System.out.print("Solucao ");
      for(int i=0;i<size;i++)
      {
        if(removidos[i]>=0 && removidos[i+1]>=0)
        {
        System.out.print(" x:"+removidos[i]+" y:"+removidos[i+1]);
      }
        i++;
      }
      System.out.println();
    }

public static void BFS_Search(boolean[] map, int nretangulos,BSTree<Integer> arvore)
{
  int flag=0;
  int[] backup=new int[2];
  int[] solucao=new int[vertices_existentes*2];
  int[] removidos=new int[vertices_existentes*2];
  array_fill(removidos,vertices_existentes*2);
  int i=0;
  int j=0;
  int h=0;
  System.out.println("Numero retangulos:"+numero_retangulos);
        while(contar(solucao,nretangulos)!= ((numero_retangulos/3)+1))
        {
          clear_map(map,nretangulos);
            i=0;
            j=0;
          if(flag>=1)
           {
                  colocar(backup[0],backup[1],arvore);
                  while(pertence(solucao[j],solucao[j+1],removidos)==1)
                  {
                    j++;
                    j++;
                  }
                  removidos[h]=solucao[j];
                  removidos[h+1]=solucao[j+1];
                  //printar_removidos(removidos,vertices_existentes*2);
                  backup[0]=solucao[j];
                  backup[1]=solucao[j+1];
                  //printar_removidos(solucao,);
                  remover(solucao[j],solucao[j+1],arvore);
                  //System.out.println("fim");
                  h++;h++;
           }
                     array_fill(solucao,vertices_existentes*2);
          //System.out.println(flag);
              MyQueue<BSTNode<Integer>> q = new LinkedListQueue<BSTNode<Integer>>();
              //if(contar_false(map,nretangulos)>=3)  // Verificar na arvore todos os vertices que vigiem 3 retangulos & escolher vertices que vigiem 2 caso o nº de retangulos que falte preencher n seja divisivel por 3
              //{
                q.enqueue(arvore.root);
                while (!q.isEmpty()) {
                   BSTNode<Integer> cur = q.dequeue();
                   if (cur != null && cur.invisivel==0) {
                     if(cur.contagem_cobertura(map)==3)
                     {
                       preencher(cur,map);
                       solucao[i]=cur.getx();solucao[i+1]=cur.gety();
                       i++;
                       i++;
                      // System.out.println("x: "+cur.getx()+" y:"+cur.gety());
                     }
                      q.enqueue(cur.getLeft());
                      q.enqueue(cur.getRight());
                   }
                }
            //}

              // Verificar na arvore todos os vertices que vigiem 2 retangulos & escolher vertices que vigiem 1 caso o nº de retnagulos que falte preencher n seja n divisivel por 2
              q.enqueue(arvore.root);
              while (!q.isEmpty()) {
              BSTNode<Integer> cur = q.dequeue();
                 if (cur != null && cur.invisivel==0) {
              if( cur.contagem_cobertura(map)==2)
              {
                  preencher(cur,map);
                  solucao[i]=cur.getx();solucao[i+1]=cur.gety();
                  i++;
                  i++;
                  //System.out.println("x: "+cur.getx()+" y:"+cur.gety());
                }
            q.enqueue(cur.getLeft());
            q.enqueue(cur.getRight());
          }
        }

        // Por fim , preencher os que faltam ( caso falte algum )
            q.enqueue(arvore.root);
            while (!q.isEmpty()) {
            BSTNode<Integer> cur = q.dequeue();
                 if (cur != null && cur.invisivel==0) {
              if( cur.contagem_cobertura(map)==1)
              {
                preencher(cur,map);
                solucao[i]=cur.getx();solucao[i+1]=cur.gety();
                i++;
                i++;
                //System.out.println("x: "+cur.getx()+" y:"+cur.gety());
              }
          q.enqueue(cur.getLeft());
          q.enqueue(cur.getRight());
        }
      }
     printar_solucao(solucao,vertices_existentes*2);
      if(areAllTrue(map,nretangulos)==true && contar(solucao,nretangulos)==((numero_retangulos/3)+1))
      {
        break;
      }
      if(flag==0)
      {
        backup[0]=solucao[0];
        backup[1]=solucao[1];
      }
      flag++;
    }

   for(int k=0;k<contar(solucao,nretangulos);k++)
    {
      System.out.println("x:"+solucao[k]+" y:"+solucao[k+1]);
    }
}


  public static void main(String[] args)
  {
     int flag=0;
     int nretangulos;
     Scanner in=new Scanner(System.in);
     BSTree<Integer> arvore = new BSTree<>();
     int instancias=in.nextInt();
      for(int l=1;l<=instancias;l++)
      {
        nretangulos=in.nextInt();
         boolean[] map = new boolean[nretangulos];
        Arrays.fill(map,true);
        int nr=in.nextInt();
        numero_retangulos=nr;
        for(int k=0;k<nr;k++)
        {
          int x=in.nextInt();
          map[x-1]=false;
        }
        for(int i=1;i<=nretangulos;i++)
        {
          int retangulo=in.nextInt();
          int nvertices=in.nextInt();
          vertices_existentes+=nvertices;
          for(int h=1;h<=nvertices;h++)
          {
            int x=in.nextInt();
            int y=in.nextInt();
            if(flag==0)
            {
              flag=1;
              arvore.insert(0,x,y,retangulo);
            }
            else if(flag==1)
            {
              inserir(x,y,retangulo,arvore);
            }
          }
       }
       System.out.println("Retangulo: "+l);
       BFS_Search(map,nretangulos,arvore);
       arvore.clear();
        }
  }
}
