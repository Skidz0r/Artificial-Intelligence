// -----------------------------------------------------------
// Estruturas de Dados 2018/2019 (CC1007) - DCC/FCUP
// http://www.dcc.fc.up.pt/~pribeiro/aulas/edados1819/
// -----------------------------------------------------------
// No de uma arvore binaria de pesquisa
// Ultima alteracao: 13/05/2018
// -----------------------------------------------------------

// O tipo T tem de implementar o interface Comparable
// (ou te-lo herdado de uma super classe).
public class BSTNode<T extends Comparable<? super T>> {
   private T value;          // Valor guardado no no
   private BSTNode<T> left;  // Filho esquerdo
   private BSTNode<T> right; // Filho direito
   private int x;
   private int y;
   public int[] vec;
   // Construtor
   BSTNode(T v, BSTNode<T> l, BSTNode<T> r,int cordx,int cordy,int[] i) {
      value = v;
      left = l;
      right = r;
      x = cordx;
      y= cordy;
      vec=i;
   }

   // Getters e Setters
   public T getValue() {return value;}
   public int getx() {return x;}
   public int gety() {return y;}
   public BSTNode<T> getLeft() {return left;}
   public BSTNode<T> getRight() {return right;}
   public void setx(int cordx) {x=cordx;}
   public void sety(int cordy) {y=cordy;}
   public void setValue(T v) {value = v;}
   public void insert_cobertura(int x)
   {
     int i=0;
     int flag=0;
     while(vec[i]>0)
     {
       if(vec[i]==x)
       {
         flag=1;
       }
       i++;
     }
     if(i<=2 && flag==0)
     {
       vec[i]=x;
     }
   }
   public void show_cobertura()
   {
     for(int i=0;i<3;i++)
     {
       System.out.print("vec["+i+"]:"+vec[i]);
     }
   }
   public int contagem_cobertura(boolean[] map)
   {
     int contagem=0;
     for(int i=0;i<3;i++)
     {
       if(vec[i]>0 && map[vec[i]-1]==false)
       {
         contagem++;
       }
     }
     return contagem;
   }
   public void setLeft(BSTNode<T> l) {left = l;}
   public void setRight(BSTNode<T> r) {right = r;}
}
