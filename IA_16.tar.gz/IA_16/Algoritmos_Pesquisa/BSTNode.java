public class BSTNode<T extends Comparable<? super T>> {
   private T value;          // Valor guardado no no
   private BSTNode<T> left;  // Filho esquerdo
   private BSTNode<T> right; // Filho direito
   private int x;
   private int y;
   public int invisivel;
   public int[] vec;
   // Construtor
   BSTNode(T v, BSTNode<T> l, BSTNode<T> r,int cordx,int cordy,int[] i,int inv) {
      value = v;
      left = l;
      right = r;
      x = cordx;
      y= cordy;
      vec=i;
      invisivel=inv;
   }

   // Getters e Setters
   public T getValue() {return value;}
   public int getx() {return x;}
   public int gety() {return y;}
   public int invisivel(){return invisivel;}
   public BSTNode<T> getLeft() {return left;}
   public BSTNode<T> getRight() {return right;}
   public void setx(int cordx) {x=cordx;}
   public void sety(int cordy) {y=cordy;}
   public void setValue(T v) {value = v;}
   public void insert_cobertura(int x)
   {
     int i=0;
     int flag=0;
     while(vec[i]>0)
     {
       if(vec[i]==x)
       {
         flag=1;
       }
       i++;
     }
     if(i<=2 && flag==0)
     {
       vec[i]=x;
     }
   }
   public void show_cobertura()
   {
     for(int i=0;i<3;i++)
     {
       System.out.print("vec["+i+"]:"+vec[i]);
     }
   }
   public int contagem_value()
   {
     int contagem=0;
     for(int i=0;i<3;i++)
     {
       if(vec[i]>0)
       {
         contagem++;
       }
     }
     return contagem;
   }
   public int contagem_cobertura(boolean[] map)
   {
     int contagem=0;
     for(int i=0;i<3;i++)
     {
       if(vec[i]>0 && map[vec[i]-1]==false)
       {
         contagem++;
       }
     }
     return contagem;
   }
   public void setLeft(BSTNode<T> l) {left = l;}
   public void setRight(BSTNode<T> r) {right = r;}
}
